package javazoom.jl.decoder;

public abstract interface FrameDecoder
{
  public abstract void decodeFrame();
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.FrameDecoder
 * JD-Core Version:    0.6.0
 */