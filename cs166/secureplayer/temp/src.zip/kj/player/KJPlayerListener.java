package kj.player;

public abstract interface KJPlayerListener
{
  public abstract void playerEvent(KJPlayerEvent paramKJPlayerEvent);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.player.KJPlayerListener
 * JD-Core Version:    0.6.0
 */