package kj.track;

import java.io.Serializable;

public abstract interface KJTrackProviderChangeListener extends Serializable
{
  public abstract void trackProviderChanged(KJTrackProviderChangeEvent paramKJTrackProviderChangeEvent);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.track.KJTrackProviderChangeListener
 * JD-Core Version:    0.6.0
 */