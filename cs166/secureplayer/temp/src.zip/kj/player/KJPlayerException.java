/*    */ package kj.player;
/*    */ 
/*    */ public class KJPlayerException extends RuntimeException
/*    */ {
/*    */   public KJPlayerException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public KJPlayerException(String arg0)
/*    */   {
/* 29 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public KJPlayerException(Throwable arg0)
/*    */   {
/* 37 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public KJPlayerException(String arg0, Throwable arg1)
/*    */   {
/* 46 */     super(arg0, arg1);
/*    */   }
/*    */ }

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.player.KJPlayerException
 * JD-Core Version:    0.6.0
 */