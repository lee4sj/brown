package javazoom.jl.decoder;

public abstract interface JavaLayerErrors
{
  public static final int BITSTREAM_ERROR = 256;
  public static final int DECODER_ERROR = 512;
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.JavaLayerErrors
 * JD-Core Version:    0.6.0
 */