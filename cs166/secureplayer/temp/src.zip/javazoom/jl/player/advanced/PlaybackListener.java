package javazoom.jl.player.advanced;

public abstract class PlaybackListener
{
  public void playbackStarted(PlaybackEvent evt)
  {
  }

  public void playbackFinished(PlaybackEvent evt)
  {
  }
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.player.advanced.PlaybackListener
 * JD-Core Version:    0.6.0
 */