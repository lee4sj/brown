package kj.venue;

public abstract interface KJVenueChangeListener
{
  public abstract void venueChanged(KJVenue paramKJVenue);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.venue.KJVenueChangeListener
 * JD-Core Version:    0.6.0
 */