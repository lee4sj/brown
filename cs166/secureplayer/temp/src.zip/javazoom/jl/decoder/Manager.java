package javazoom.jl.decoder;

public class Manager
{
  public void addControl(Control c)
  {
  }

  public void removeControl(Control c)
  {
  }

  public void removeAll()
  {
  }
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.Manager
 * JD-Core Version:    0.6.0
 */