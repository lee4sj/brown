/*    */ package kj.storeclient;
/*    */ 
/*    */ public class StoreTrack
/*    */ {
/* 20 */   private String path_ = null;
/* 21 */   private String name_ = null;
/*    */ 
/*    */   private StoreTrack()
/*    */   {
/*    */   }
/*    */ 
/*    */   public StoreTrack(String name, String path)
/*    */   {
/* 34 */     this.name_ = name;
/* 35 */     this.path_ = path;
/*    */   }
/*    */ 
/*    */   public String getPath()
/*    */   {
/* 44 */     return this.path_;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 54 */     return this.name_;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 67 */     String response = this.name_;
/* 68 */     if (response.endsWith(".mp3")) {
/* 69 */       response = response.substring(0, response.length() - 1).concat("S");
/*    */     }
/* 71 */     return response;
/*    */   }
/*    */ }

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.storeclient.StoreTrack
 * JD-Core Version:    0.6.0
 */