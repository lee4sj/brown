package javazoom.jl.decoder;

public class JavaLayerError extends Error
{
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.JavaLayerError
 * JD-Core Version:    0.6.0
 */