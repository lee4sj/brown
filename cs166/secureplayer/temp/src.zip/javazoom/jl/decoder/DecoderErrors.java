package javazoom.jl.decoder;

public abstract interface DecoderErrors extends JavaLayerErrors
{
  public static final int UNKNOWN_ERROR = 512;
  public static final int UNSUPPORTED_LAYER = 513;
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.DecoderErrors
 * JD-Core Version:    0.6.0
 */