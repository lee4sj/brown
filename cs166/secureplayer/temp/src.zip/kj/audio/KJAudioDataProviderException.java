/*    */ package kj.audio;
/*    */ 
/*    */ public class KJAudioDataProviderException extends RuntimeException
/*    */ {
/*    */   public KJAudioDataProviderException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public KJAudioDataProviderException(String arg0)
/*    */   {
/* 29 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public KJAudioDataProviderException(Throwable arg0)
/*    */   {
/* 37 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public KJAudioDataProviderException(String arg0, Throwable arg1)
/*    */   {
/* 46 */     super(arg0, arg1);
/*    */   }
/*    */ }

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.audio.KJAudioDataProviderException
 * JD-Core Version:    0.6.0
 */