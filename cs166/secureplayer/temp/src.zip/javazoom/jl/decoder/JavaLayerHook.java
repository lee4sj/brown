package javazoom.jl.decoder;

import java.io.InputStream;

public abstract interface JavaLayerHook
{
  public abstract InputStream getResourceAsStream(String paramString);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.JavaLayerHook
 * JD-Core Version:    0.6.0
 */