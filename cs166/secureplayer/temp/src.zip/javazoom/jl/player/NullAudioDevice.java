/*    */ package javazoom.jl.player;
/*    */ 
/*    */ public class NullAudioDevice extends AudioDeviceBase
/*    */ {
/*    */   public int getPosition()
/*    */   {
/* 35 */     return 0;
/*    */   }
/*    */ }

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.player.NullAudioDevice
 * JD-Core Version:    0.6.0
 */