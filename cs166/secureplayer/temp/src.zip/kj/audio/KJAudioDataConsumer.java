package kj.audio;

public abstract interface KJAudioDataConsumer
{
  public abstract void writeAudioData(byte[] paramArrayOfByte, boolean paramBoolean);

  public abstract void writeAudioData(byte[] paramArrayOfByte, int paramInt1, int paramInt2, boolean paramBoolean);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.audio.KJAudioDataConsumer
 * JD-Core Version:    0.6.0
 */