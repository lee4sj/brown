package kj.xml;

import org.w3c.dom.Element;

public abstract interface KJXmlSerializable
{
  public abstract void readXml(Element paramElement);

  public abstract void writeXml(Element paramElement);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.xml.KJXmlSerializable
 * JD-Core Version:    0.6.0
 */