package javazoom.jl.decoder;

public abstract interface Control
{
  public abstract void start();

  public abstract void stop();

  public abstract boolean isPlaying();

  public abstract void pause();

  public abstract boolean isRandomAccess();

  public abstract double getPosition();

  public abstract void setPosition(double paramDouble);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     javazoom.jl.decoder.Control
 * JD-Core Version:    0.6.0
 */