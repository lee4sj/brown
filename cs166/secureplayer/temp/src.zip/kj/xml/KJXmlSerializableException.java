/*    */ package kj.xml;
/*    */ 
/*    */ public class KJXmlSerializableException extends RuntimeException
/*    */ {
/*    */   public KJXmlSerializableException(String pMessage)
/*    */   {
/* 21 */     super(pMessage);
/*    */   }
/*    */ }

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.xml.KJXmlSerializableException
 * JD-Core Version:    0.6.0
 */