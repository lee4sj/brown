package kj.track;

public abstract interface KJTrackProvider
{
  public abstract void addListener(KJTrackProviderChangeListener paramKJTrackProviderChangeListener);

  public abstract KJTrack nextTrack();

  public abstract void removeListener(KJTrackProviderChangeListener paramKJTrackProviderChangeListener);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.track.KJTrackProvider
 * JD-Core Version:    0.6.0
 */