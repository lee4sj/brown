package kj.dsp;

public abstract interface KJDigitalSignalProcessor
{
  public abstract void process(float[] paramArrayOfFloat1, float[] paramArrayOfFloat2, float paramFloat);
}

/* Location:           /home/sl136/course/cs166/secureplayer/SecurePlayer.jar
 * Qualified Name:     kj.dsp.KJDigitalSignalProcessor
 * JD-Core Version:    0.6.0
 */